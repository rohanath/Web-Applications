

Open two terminals and follow these steps on the terminals to start the servers:

Back-end server
	1. cd node
	2. npm install
	3. npm start

Front-end server
	1. cd react
	2. npm install
	3. npm start

	Make sure there is an 'uploads' folder inside react-->public.
