To run the application, use:

nodemon app.js 

The server will be active on port 1234 after execution.